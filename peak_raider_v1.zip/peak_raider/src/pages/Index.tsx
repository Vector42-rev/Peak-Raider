"use client";

import { useState, useEffect, useMemo } from "react";
import { ProjectCard, type Project } from "@/components/ProjectCard";
import { SearchBar } from "@/components/SearchBar";
import { StatsOverview } from "@/components/StatsOverview";
import { CreateProjectDialog } from "@/components/CreateProjectDialog";
import { Button } from "@/components/ui/button";
import { BookOpen, Sparkles, ArrowRight } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { motion } from "framer-motion";
import { ShaderAnimation } from "@/components/ui/shader-lines";

const Index = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("modified");
  const [filters, setFilters] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // 🔥 Fetch projects from Supabase
  const fetchProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("RD_Projects")
      .select("*")
      .order("lastModified", { ascending: false });

    if (error) {
      console.error("Error fetching projects:", error);
    } else if (data) {
      setProjects(
        data.map((row: any) => ({
          id: row.project_id ?? crypto.randomUUID(),
          name: row.project_name ?? "Untitled Project",
          description: row.project_description ?? "",
          paperCount: row.paperCount ?? 0,
          topicCount: row.topicCount ?? 0,
          lastModified: row.lastModified ?? new Date().toISOString(),
          progress: row.progress ?? 0,
          color: row.color ?? "#22c55e",
          status: row.status ?? "active",
        }))
      );
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  // 🔥 Create project in Supabase
  const handleCreateProject = async (projectData: {
    name: string;
    description: string;
  }) => {
    console.log("Creating project:", projectData);

    // 1️⃣ Fetch current max(project_id)
    const { data: maxData, error: maxError } = await supabase
      .from("RD_Projects")
      .select("project_id")
      .order("project_id", { ascending: false })
      .limit(1)
      .single();

    if (maxError && maxError.code !== "PGRST116") { // ignore empty table error
      console.error("❌ Error fetching max project_id:", maxError);
      alert(`Error fetching max ID: ${maxError.message}`);
      return;
    }

    const nextId = (maxData?.project_id ?? 0) + 1;
    console.log("Next project_id will be:", nextId);

    // 2️⃣ Insert new project with computed ID
    const { data, error } = await supabase
      .from("RD_Projects")
      .insert([
        {
          project_id: nextId,
          project_name: projectData.name || "Untitled Project",
          project_description: projectData.description || "",
          paperCount: 0,
          topicCount: 0,
          lastModified: new Date().toISOString(),
          progress: 0,
          status: "active",
        },
      ])
      .select()
      .single();

    if (error) {
      console.error("❌ Supabase insert error:", error);
      alert(`Error creating project: ${error.message}`);
      return;
    }

    console.log("✅ Project created:", data);

    // 3️⃣ Update UI immediately
    setProjects((prev) => [
      {
        id: data.project_id,
        name: data.project_name,
        description: data.project_description,
        paperCount: data.paperCount ?? 0,
        topicCount: data.topicCount ?? 0,
        lastModified: data.lastModified ?? new Date().toISOString(),
        progress: data.progress ?? 0,
        color: "#22c55e",
        status: data.status ?? "active",
      },
      ...prev,
    ]);
  };


  // ✅ Filter & Sort
  const filteredAndSortedProjects = useMemo(() => {
    let filtered = projects.filter((project) =>
      (project.name ?? "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (project.description ?? "").toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (filters.length > 0) {
      filtered = filtered.filter((project) =>
        filters.some((filter) => {
          switch (filter) {
            case "active":
              return project.status === "active";
            case "completed":
              return project.status === "completed";
            case "archived":
              return project.status === "archived";
            case "high-progress":
              return (project.progress ?? 0) >= 80;
            case "recent":
              return project.lastModified?.includes("hour") || project.lastModified?.includes("day");
            default:
              return true;
          }
        })
      );
    }

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case "name":
          return (a.name ?? "").localeCompare(b.name ?? "");
        case "progress":
          return (b.progress ?? 0) - (a.progress ?? 0);
        case "papers":
          return (b.paperCount ?? 0) - (a.paperCount ?? 0);
        case "modified":
        default:
          return 0;
      }
    });
  }, [projects, searchTerm, sortBy, filters]);

  // ✅ Stats
  const stats = useMemo(
    () => ({
      totalProjects: projects.length,
      totalTopics: projects.reduce((sum, p) => sum + (p.topicCount ?? 0), 0),
      totalPapers: projects.reduce((sum, p) => sum + (p.paperCount ?? 0), 0),
      recentActivity: 3,
      completionRate:
        projects.length > 0
          ? Math.round(projects.reduce((sum, p) => sum + (p.progress ?? 0), 0) / projects.length)
          : 0,
    }),
    [projects]
  );

  const handleProjectClick = (project: Project) => {
    console.log("Opening project:", project.name);
  };

  return (
    <div className="min-h-screen bg-black text-white selection:bg-primary selection:text-black">
      {/* Hero Section - Black & Green with Shader Animation */}
      <div className="relative overflow-hidden border-b border-white/10">
        {/* Shader Animation Background */}
        <ShaderAnimation />

        {/* Subtle Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />

        {/* Green Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />

        <div className="relative container mx-auto px-4 py-24 sm:py-32 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center justify-center gap-3 mb-6"
          >
            <div className="p-3 bg-primary/10 rounded-2xl border border-primary/20">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold tracking-tight mb-6"
          >
            Peak <span className="text-primary">Raider</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-zinc-400 mb-10 max-w-2xl mx-auto leading-relaxed"
          >
            Premium literature survey and note-taking platform for academic research.
            Organize, analyze, and synthesize with precision.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <CreateProjectDialog onCreateProject={handleCreateProject} />
            <Button
              variant="outline"
              size="lg"
              className="border-zinc-800 text-zinc-300 hover:bg-zinc-900 hover:text-white hover:border-zinc-700 h-12 px-8 text-base"
            >
              Browse Templates
            </Button>
          </motion.div>
        </div>
      </div>


      {/* Main Content */}
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mb-16"
        >
          <StatsOverview stats={stats} />
        </motion.div>

        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-10">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
              Your Projects <ArrowRight className="h-5 w-5 text-primary -rotate-45" />
            </h2>
            <p className="text-zinc-500 text-lg">
              Manage your research projects and literature surveys
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <CreateProjectDialog onCreateProject={handleCreateProject} />
          </motion.div>
        </div>

        <div className="mb-8">
          <SearchBar
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
            sortBy={sortBy}
            onSortChange={setSortBy}
            filters={filters}
            onFiltersChange={setFilters}
          />
        </div>

        {loading ? (
          <div className="text-center py-24">
            <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-zinc-500">Loading projects...</p>
          </div>
        ) : filteredAndSortedProjects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <ProjectCard
                  project={project}
                  onClick={handleProjectClick}
                  onEdit={(p) => console.log("Edit project:", p)}
                  onDelete={(p) => console.log("Delete project:", p)}
                  onArchive={(p) => console.log("Archive project:", p)}
                />
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-24 border border-dashed border-zinc-800 rounded-2xl bg-zinc-900/30"
          >
            <BookOpen className="h-16 w-16 mx-auto text-zinc-700 mb-4" />
            <h3 className="text-xl font-semibold mb-2 text-white">No projects found</h3>
            <p className="text-zinc-500 mb-6 max-w-md mx-auto">
              {searchTerm || filters.length > 0
                ? "Try adjusting your search or filters to find what you're looking for."
                : "Create your first research project to get started with your literature survey."}
            </p>
            {!searchTerm && filters.length === 0 && (
              <CreateProjectDialog onCreateProject={handleCreateProject} />
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Index;
