import { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button, buttonVariants } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import { PDFViewer } from "@/components/PDFViewer";
import { ArrowLeft, Calendar, Users, ExternalLink, Plus, X, Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { cn } from "@/lib/utils";
import { ShaderAnimation } from "@/components/ui/shader-lines";

interface Note {
  notes_id: number;
  project_id: number;
  topic_id: number;
  paper_id: number;
  paper_page: number | null;
  content: string;
  createdAt: string;
  updatedAt: string;
}

interface PaperData {
  paper_id: number;
  project_id: number;
  topic_id: number;
  paper_title: string;
  paper_author: string;
  paper_journal: string;
  paper_doi: string;
  file_path: string;
  created_at: string;
}

const DARK_NOTE_COLORS = [
  { bg: "bg-zinc-900", border: "border-zinc-800", text: "text-zinc-100" },
  { bg: "bg-zinc-900", border: "border-green-900/50", text: "text-zinc-100" },
  { bg: "bg-zinc-900", border: "border-zinc-800", text: "text-zinc-100" },
];

const PaperViewer = () => {
  const { projectId, topicId, paperId } = useParams<{
    projectId: string;
    topicId: string;
    paperId: string;
  }>();

  const [paper, setPaper] = useState<PaperData | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [notes, setNotes] = useState<Note[]>([]);
  const [loadingNotes, setLoadingNotes] = useState(false);
  const [showNewNote, setShowNewNote] = useState(false);
  const [newNoteContent, setNewNoteContent] = useState("");
  const [savingNote, setSavingNote] = useState(false);
  const [pdfError, setPdfError] = useState(false);

  // Load paper metadata + PDF
  useEffect(() => {
    const fetchPaper = async () => {
      try {
        const { data, error } = await supabase
          .from("RD_Papers")
          .select("*")
          .eq("project_id", Number(projectId))
          .eq("topic_id", Number(topicId))
          .eq("paper_id", Number(paperId))
          .single();

        if (error) throw error;
        setPaper(data);

        await loadPDF(data.file_path);
      } catch (err) {
        console.error("Error loading paper:", err);
        setPdfError(true);
      } finally {
        setLoading(false);
      }
    };

    const loadPDF = async (url: string) => {
      if (!url) {
        setPdfError(true);
        return;
      }

      try {
        const cache = await caches.open("pdf-cache");
        const cached = await cache.match(url);

        if (cached) {
          const blob = await cached.blob();
          setPdfUrl(URL.createObjectURL(blob));
        } else {
          const response = await fetch(url);
          if (!response.ok) throw new Error("Failed to fetch PDF");

          const responseClone = response.clone();
          const blob = await response.blob();
          await cache.put(url, responseClone);
          setPdfUrl(URL.createObjectURL(blob));
        }
      } catch (err) {
        console.error("Error loading PDF:", err);
        setPdfError(true);
      }
    };

    fetchPaper();
  }, [paperId, projectId, topicId]);

  // Fetch notes for current page
  const fetchNotesForPage = useCallback(async (page: number) => {
    if (!paperId) return;

    setLoadingNotes(true);
    try {
      const { data, error } = await supabase
        .from("RD_Notes")
        .select("*")
        .eq("paper_id", Number(paperId))
        .eq("paper_page", page)
        .order("createdAt", { ascending: false });

      if (error) throw error;
      setNotes(data || []);
    } catch (err) {
      console.error("Error fetching notes:", err);
    } finally {
      setLoadingNotes(false);
    }
  }, [paperId]);

  // Handle page change from PDF viewer
  const handlePageChange = useCallback((page: number) => {
    setCurrentPage(page);
    setShowNewNote(false);
    setNewNoteContent("");
    fetchNotesForPage(page);
  }, [fetchNotesForPage]);

  // Load initial notes
  useEffect(() => {
    if (paperId) {
      fetchNotesForPage(currentPage);
    }
  }, [paperId, fetchNotesForPage]);

  // Save new note
  const handleSaveNote = async () => {
    if (!newNoteContent.trim() || !paper) return;

    setSavingNote(true);
    try {
      const { data: existingNotes, error: fetchError } = await supabase
        .from("RD_Notes")
        .select("notes_id")
        .eq("project_id", paper.project_id)
        .eq("topic_id", paper.topic_id)
        .eq("paper_id", paper.paper_id)
        .order("notes_id", { ascending: false })
        .limit(1);

      if (fetchError) throw fetchError;

      const maxNotesId = existingNotes && existingNotes.length > 0
        ? existingNotes[0].notes_id
        : 0;
      const newNotesId = maxNotesId + 1;

      const now = new Date().toISOString();
      const newNote = {
        notes_id: newNotesId,
        project_id: paper.project_id,
        topic_id: paper.topic_id,
        paper_id: paper.paper_id,
        paper_page: currentPage,
        content: newNoteContent.trim(),
        createdAt: now,
        updatedAt: now,
      };

      const { error: insertError } = await supabase
        .from("RD_Notes")
        .insert(newNote);

      if (insertError) throw insertError;

      await fetchNotesForPage(currentPage);
      setNewNoteContent("");
      setShowNewNote(false);
    } catch (err) {
      console.error("Error saving note:", err);
      alert("Failed to save note. Please try again.");
    } finally {
      setSavingNote(false);
    }
  };

  // Delete note
  const handleDeleteNote = async (noteId: number) => {
    try {
      const { error } = await supabase
        .from("RD_Notes")
        .delete()
        .eq("notes_id", noteId);

      if (error) throw error;

      await fetchNotesForPage(currentPage);
    } catch (err) {
      console.error("Error deleting note:", err);
    }
  };

  if (loading || !paper)
    return (
      <div className="min-h-screen flex items-center justify-center bg-black text-white">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );

  return (
    <motion.div
      className="h-screen flex flex-col bg-black text-white"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {/* Header */}
      <div className="border-b border-zinc-800 px-4 py-4 flex items-center justify-between bg-black/50 backdrop-blur-md relative overflow-hidden">
        <ShaderAnimation />
        <div className="flex items-center gap-4 min-w-0 flex-1 relative z-10">
          <Link
            to={`/project/${projectId}/topic/${topicId}`}
            className={cn(
              buttonVariants({ variant: "ghost", size: "sm" }),
              "text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all duration-300"
            )}
          >
            <ArrowLeft className="h-4 w-4 mr-2" /> Back
          </Link>
          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-bold truncate text-white">
              {paper.paper_title}
            </h1>
            <div className="flex items-center gap-4 text-sm text-zinc-500 mt-1">
              <span className="flex items-center gap-1">
                <Users className="h-3.5 w-3.5 text-primary" /> {paper.paper_author || "Unknown"}
              </span>
              {paper.paper_journal && (
                <>
                  <Separator orientation="vertical" className="h-3 bg-zinc-700" />
                  <span>{paper.paper_journal}</span>
                </>
              )}
              <Separator orientation="vertical" className="h-3 bg-zinc-700" />
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5 text-primary" /> {paper.created_at?.slice(0, 10)}
              </span>
            </div>
          </div>
        </div>
        {paper.paper_doi && (
          <div className="relative z-10">
            <Button variant="outline" size="sm" asChild className="border-zinc-700 text-zinc-300 hover:bg-zinc-800 hover:text-white transition-all duration-300">
              <a href={`https://doi.org/${paper.paper_doi}`} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4 mr-2" /> DOI
              </a>
            </Button>
          </div>
        )}
      </div>

      {/* Main viewer */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal" className="h-full">
          {/* PDF Panel */}
          <ResizablePanel defaultSize={70} minSize={30} className="bg-zinc-900">
            {pdfUrl && !pdfError ? (
              <PDFViewer pdfUrl={pdfUrl} onPageChange={handlePageChange} />
            ) : (
              <div className="flex h-full items-center justify-center text-zinc-500">
                Unable to load PDF
              </div>
            )}
          </ResizablePanel>

          <ResizableHandle withHandle className="bg-zinc-800 hover:bg-primary/50 transition-colors" />

          {/* Notes Panel */}
          <ResizablePanel defaultSize={30} minSize={20} className="bg-black border-l border-zinc-800">
            <div className="h-full flex flex-col">
              <div className="p-4 border-b border-zinc-800 bg-black/50 backdrop-blur-md">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xl font-bold text-white">
                    Notes
                  </h2>
                  <Button
                    size="sm"
                    onClick={() => setShowNewNote(!showNewNote)}
                    className="bg-primary text-black hover:bg-primary/90 transition-all duration-300 font-medium"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Note
                  </Button>
                </div>
                <p className="text-sm text-zinc-500">
                  Viewing notes for <span className="font-semibold text-primary">Page {currentPage}</span>
                </p>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
                {/* Loading State */}
                {loadingNotes && (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                )}

                {/* New Note Form */}
                <AnimatePresence>
                  {showNewNote && !loadingNotes && (
                    <motion.div
                      initial={{ opacity: 0, y: -20, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -20, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      className="bg-zinc-900 border border-zinc-700 rounded-lg p-4 shadow-lg relative"
                    >
                      <Textarea
                        value={newNoteContent}
                        onChange={(e) => setNewNoteContent(e.target.value)}
                        placeholder="Write your note here..."
                        className="resize-none bg-transparent border-none focus-visible:ring-0 text-white placeholder:text-zinc-600 mb-2 min-h-[100px]"
                        disabled={savingNote}
                      />
                      <div className="flex gap-2 justify-end">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setShowNewNote(false);
                            setNewNoteContent("");
                          }}
                          disabled={savingNote}
                          className="text-zinc-400 hover:text-white hover:bg-zinc-800"
                        >
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          onClick={handleSaveNote}
                          disabled={!newNoteContent.trim() || savingNote}
                          className="bg-primary text-black hover:bg-primary/90"
                        >
                          {savingNote ? (
                            <>
                              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            "Save Note"
                          )}
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Existing Notes */}
                {!loadingNotes && notes.length === 0 && !showNewNote && (
                  <div className="text-center py-12 text-zinc-600">
                    <p className="text-sm">No notes for page {currentPage} yet.</p>
                    <p className="text-xs mt-1">Click "Add Note" to create one!</p>
                  </div>
                )}

                <AnimatePresence>
                  {!loadingNotes && notes.map((note, index) => {
                    const color = DARK_NOTE_COLORS[index % DARK_NOTE_COLORS.length];

                    return (
                      <motion.div
                        key={note.notes_id}
                        initial={{ opacity: 0, y: 20, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ duration: 0.2, delay: index * 0.05 }}
                        className={`${color.bg} border ${color.border} rounded-lg p-4 shadow-md hover:shadow-glow-sm transition-all relative group`}
                      >
                        <button
                          onClick={() => handleDeleteNote(note.notes_id)}
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-zinc-500 hover:text-red-400"
                        >
                          <X className="h-4 w-4" />
                        </button>
                        <p className={`${color.text} text-sm leading-relaxed pr-6 whitespace-pre-wrap`}>
                          {note.content}
                        </p>
                        <div className="text-zinc-500 text-xs mt-3 text-right">
                          {new Date(note.updatedAt).toLocaleDateString()} {new Date(note.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </motion.div>
  );
};

export default PaperViewer;