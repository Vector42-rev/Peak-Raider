"use client";

import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, Edit } from "lucide-react";
import { Input } from "@/components/ui/input";
import { supabase } from "@/lib/supabase";
import { ShaderAnimation } from "@/components/ui/shader-lines";

interface Paper {
  paper_id: number;
  paper_title: string;
  paper_author: string;
  paper_journal: string;
  paper_doi: string;
  file_path: string;
  reading_progress: number;
  created_at: string;
  project_id: number;
  topic_id: number;
}

interface Topic {
  topic_id: number;
  topic_name: string;
  topic_description: string;
  paperCount: number;
  createdAt: string;
  lastModified: string;
  project_id: number;
}

const TopicDetail = () => {
  const { projectId, topicId } = useParams<{ projectId: string; topicId: string }>();
  const navigate = useNavigate();

  const [topic, setTopic] = useState<Topic | null>(null);
  const [papers, setPapers] = useState<Paper[]>([]);
  const [loading, setLoading] = useState(true);

  // --- Edit Topic State ---
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editDescription, setEditDescription] = useState("");

  // --- Add Paper State ---
  const [showAddPaper, setShowAddPaper] = useState(false);
  const [paperTitle, setPaperTitle] = useState("");
  const [paperAuthor, setPaperAuthor] = useState("");
  const [paperJournal, setPaperJournal] = useState("");
  const [paperDOI, setPaperDOI] = useState("");
  const [filePath, setFilePath] = useState("");

  // --- Fetch Topic ---
  const fetchTopic = async () => {
    if (!topicId) return;
    setLoading(true);

    const { data, error } = await supabase
      .from("RD_Topics")
      .select("*")
      .eq("project_id", Number(projectId))
      .eq("topic_id", Number(topicId))
      .single();

    if (error || !data) {
      console.error("Error loading topic:", error);
      setTopic(null);
      setLoading(false);
      return;
    }

    setTopic({
      topic_id: data.topic_id,
      topic_name: data.topic_name ?? "Untitled Topic",
      topic_description: data.topic_description ?? "",
      paperCount: data.paperCount ?? 0,
      createdAt: data.createdAt ?? new Date().toISOString(),
      lastModified: data.lastModified ?? new Date().toISOString(),
      project_id: data.project_id,
    });
    setEditName(data.topic_name ?? "");
    setEditDescription(data.topic_description ?? "");
    setLoading(false);
  };

  // --- Fetch Papers ---
  const fetchPapers = async () => {
    if (!projectId || !topicId) return;

    const { data, error } = await supabase
      .from("RD_Papers")
      .select("*")
      .eq("project_id", Number(projectId))
      .eq("topic_id", Number(topicId))
      .order("paper_id", { ascending: true });

    if (error) {
      console.error("Error fetching papers:", error);
      setPapers([]);
    } else {
      setPapers(data ?? []);
      setTopic((prev) =>
        prev ? { ...prev, paperCount: data?.length ?? 0 } : prev
      );
    }
  };

  useEffect(() => {
    fetchTopic().then(fetchPapers);
  }, [projectId, topicId]);

  // --- Update Topic ---
  const handleUpdateTopic = async () => {
    if (!topic) return;

    const { error } = await supabase
      .from("RD_Topics")
      .update({
        topic_name: editName,
        topic_description: editDescription,
        lastModified: new Date().toISOString(),
      })
      .eq("project_id", Number(projectId))
      .eq("topic_id", Number(topic.topic_id));

    if (error) {
      alert(`Error updating topic: ${error.message}`);
      return;
    }

    setTopic((prev) =>
      prev
        ? {
          ...prev,
          topic_name: editName,
          topic_description: editDescription,
          lastModified: new Date().toISOString(),
        }
        : prev
    );
    setIsEditing(false);
  };

  // --- Add Paper ---
  const handleAddPaper = async () => {
    if (!projectId || !topicId) return;

    // Generate unique paper_id
    const { data: maxPaper } = await supabase
      .from("RD_Papers")
      .select("paper_id")
      .order("paper_id", { ascending: false })
      .limit(1)
      .single();

    const nextPaperId = (maxPaper?.paper_id ?? 0) + 1;

    const { error } = await supabase.from("RD_Papers").insert([
      {
        paper_id: nextPaperId,
        paper_title: paperTitle || "Untitled Paper",
        paper_author: paperAuthor || "",
        paper_journal: paperJournal || "",
        paper_doi: paperDOI || "",
        file_path: filePath || "",
        reading_progress: 0,
        project_id: Number(projectId),
        topic_id: Number(topicId),
      },
    ]);

    if (error) {
      console.error("Error adding paper:", error);
      alert("Failed to add paper");
      return;
    }

    // Reset form
    setPaperTitle("");
    setPaperAuthor("");
    setPaperJournal("");
    setPaperDOI("");
    setFilePath("");
    setShowAddPaper(false);

    await fetchPapers();

    // Navigate to PaperViewer
    navigate(`/project/${projectId}/topic/${topicId}/paper/${nextPaperId}`);
  };

  if (loading)
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-b-2 border-primary rounded-full"></div>
      </div>
    );

  if (!topic)
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Topic Not Found</h2>
          <p className="text-muted-foreground mb-4">The requested topic could not be found.</p>
          <Link to={`/project/${projectId}`}>
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Project
            </Button>
          </Link>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <ShaderAnimation />
      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Link to={`/project/${projectId}`} className={buttonVariants({ variant: "ghost", size: "sm" })}>
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Topics
          </Link>

          {isEditing ? (
            <div className="flex flex-col gap-2 flex-1 mx-4">
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Topic Name"
              />
              <textarea
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                placeholder="Topic Description"
                className="border rounded p-2 w-full"
              />
              <div className="flex gap-2">
                <Button onClick={handleUpdateTopic}>Save</Button>
                <Button variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex-1 mx-4">
              <h1 className="text-3xl font-bold mb-2">{topic.topic_name}</h1>
              <p className="text-muted-foreground mb-2">
                {topic.topic_description || "No description"}
              </p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>📄 {topic.paperCount} Papers</span>
                <span>
                  ⏱️ Last modified: {new Date(topic.lastModified).toLocaleString()}
                </span>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="mt-2"
                onClick={() => setIsEditing(true)}
              >
                <Edit className="h-4 w-4 mr-2" /> Edit Topic
              </Button>
            </div>
          )}
        </div>

        {/* Add Paper */}
        {showAddPaper && (
          <Card className="mb-6">
            <CardContent className="space-y-3">
              <Input
                placeholder="Title"
                value={paperTitle}
                onChange={(e) => setPaperTitle(e.target.value)}
              />
              <Input
                placeholder="Author"
                value={paperAuthor}
                onChange={(e) => setPaperAuthor(e.target.value)}
              />
              <Input
                placeholder="Journal"
                value={paperJournal}
                onChange={(e) => setPaperJournal(e.target.value)}
              />
              <Input
                placeholder="DOI"
                value={paperDOI}
                onChange={(e) => setPaperDOI(e.target.value)}
              />
              <Input
                placeholder="File Path (bucket URL)"
                value={filePath}
                onChange={(e) => setFilePath(e.target.value)}
              />
              <div className="flex gap-2">
                <Button onClick={handleAddPaper}>Add Paper</Button>
                <Button variant="outline" onClick={() => setShowAddPaper(false)}>
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Papers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {papers.map((paper) => (
            <motion.div
              key={paper.paper_id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="cursor-pointer"
              onClick={() =>
                navigate(`/project/${projectId}/topic/${topicId}/paper/${paper.paper_id}`)
              }
            >
              <Card className="h-full hover:shadow-lg transition group relative overflow-hidden border-zinc-800 bg-zinc-900/50">
                {/* Shader Animation Background */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-15 transition-opacity duration-500">
                  <ShaderAnimation />
                </div>

                <CardHeader className="relative z-10">
                  <div className="flex items-center justify-between">
                    <div className="w-3 h-3 rounded-full bg-primary shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                    <Badge variant="secondary" className="text-xs bg-zinc-800 text-zinc-300">
                      {paper.paper_author || "Unknown"}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg group-hover:text-primary transition-colors duration-300">
                    {paper.paper_title}
                  </CardTitle>
                  <CardDescription>
                    {paper.paper_journal || "No Journal"} • {paper.created_at?.slice(0, 10)}
                  </CardDescription>
                </CardHeader>
                <CardContent className="relative z-10">
                  <p className="text-xs text-muted-foreground">
                    DOI: {paper.paper_doi || "N/A"}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {!showAddPaper && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="cursor-pointer"
              onClick={() => setShowAddPaper(true)}
            >
              <Card className="h-full border-dashed border-2 hover:border-primary/50 transition-colors group relative overflow-hidden bg-zinc-900/30">
                {/* Shader Animation Background */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500">
                  <ShaderAnimation />
                </div>

                <CardContent className="h-full flex items-center justify-center p-8 relative z-10">
                  <div className="text-center">
                    <Plus className="h-6 w-6 text-muted-foreground group-hover:text-primary mx-auto mb-3 transition-colors duration-300" />
                    <h3 className="font-medium group-hover:text-primary transition-colors duration-300">Add New Paper</h3>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TopicDetail;
