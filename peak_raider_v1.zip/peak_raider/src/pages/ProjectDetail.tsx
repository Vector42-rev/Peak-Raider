"use client";

import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import {
  ArrowLeft,
  Plus,
  BookOpen,
  FileText,
  Clock,
  Target,
  MoreVertical,
  Edit,
} from "lucide-react";
import { supabase } from "@/lib/supabase";
import { Project } from "@/types";
import { ShaderAnimation } from "@/components/ui/shader-lines";

// Random colors for UI (since DB doesn’t have color)
const randomColors = ["#3B82F6", "#10B981", "#F59E0B", "#8B5CF6", "#EF4444"];
const getRandomColor = () =>
  randomColors[Math.floor(Math.random() * randomColors.length)];

const ProjectDetail = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);

  // --- Edit Project State ---
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editDescription, setEditDescription] = useState("");

  // --- Add Topic State ---
  const [showAddTopic, setShowAddTopic] = useState(false);
  const [topicName, setTopicName] = useState("");
  const [topicDescription, setTopicDescription] = useState("");

  const [topics, setTopics] = useState<any[]>([]);

  // --- Fetch Project ---
  const fetchProject = async () => {
    if (!projectId) return;
    setLoading(true);

    const { data, error } = await supabase
      .from("RD_Projects")
      .select("*")
      .eq("project_id", Number(projectId))
      .single();

    if (error || !data) {
      console.error("Error loading project:", error);
      setProject(null);
      setLoading(false);
      return;
    }

    const mapped: Project = {
      id: String(data.project_id),
      name: data.project_name ?? "Untitled Project",
      description: data.project_description ?? "",
      paperCount: data.paperCount ?? 0,
      topicCount: data.topicCount ?? 0,
      lastModified: data.lastModified
        ? new Date(data.lastModified).toLocaleString()
        : "N/A",
      progress: data.progress ?? 0,
      color: getRandomColor(),
      status: data.status ?? "active",
      createdAt: data.lastModified
        ? new Date(data.lastModified).toISOString()
        : new Date().toISOString(),
      topics: [],
    };

    setProject(mapped);
    setEditName(mapped.name);
    setEditDescription(mapped.description);
    setLoading(false);
  };

  // --- Fetch Topics ---
  const fetchTopics = async () => {
    if (!projectId) return;

    const { data, error } = await supabase
      .from("RD_Topics")
      .select("*")
      .eq("project_id", Number(projectId))
      .order("topic_id", { ascending: true });

    if (error) {
      console.error("Error fetching topics:", error);
      setTopics([]);
      return;
    }

    setTopics(data ?? []);

    // Update topicCount in project UI
    setProject((prev) =>
      prev ? { ...prev, topicCount: data?.length ?? 0 } : prev
    );
  };

  useEffect(() => {
    if (projectId) {
      fetchProject().then(fetchTopics);
    }
  }, [projectId]);

  // --- Update Project ---
  const handleUpdateProject = async () => {
    if (!project) return;

    const { error } = await supabase
      .from("RD_Projects")
      .update({
        project_name: editName,
        project_description: editDescription,
        lastModified: new Date().toISOString(),
      })
      .eq("project_id", Number(project.id));

    if (error) {
      alert(`Error updating project: ${error.message}`);
      return;
    }

    setProject((prev) =>
      prev
        ? {
          ...prev,
          name: editName,
          description: editDescription,
          lastModified: new Date().toLocaleString(),
        }
        : prev
    );
    setIsEditing(false);
  };

  // --- Add Topic ---
  const handleAddTopic = async () => {
    if (!project) return;

    // Get max topic_id
    const { data: maxTopic, error: maxError } = await supabase
      .from("RD_Topics")
      .select("topic_id")
      .order("topic_id", { ascending: false })
      .limit(1)
      .single();

    if (maxError && maxError.code !== "PGRST116") {
      alert(`Error fetching topic ID: ${maxError.message}`);
      return;
    }

    const nextTopicId = (maxTopic?.topic_id ?? 0) + 1;

    const { error } = await supabase.from("RD_Topics").insert([
      {
        topic_id: nextTopicId,
        topic_name: topicName || "Untitled Topic",
        topic_description: topicDescription || "",
        paperCount: 0,
        createdAt: new Date().toISOString(),
        project_id: Number(project.id),
      },
    ]);

    if (error) {
      alert(`Error creating topic: ${error.message}`);
      return;
    }

    setTopicName("");
    setTopicDescription("");
    setShowAddTopic(false);

    // Refresh topics
    fetchTopics();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Project Not Found</h2>
          <p className="text-muted-foreground mb-4">
            The requested project could not be found.
          </p>
          <Link to="/">
            <Button>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Projects
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background bg-dots">
      {/* Header with Gradient and Shader Animation */}
      <div className="border-b border-border/30 bg-gradient-to-br from-primary/10 via-accent/5 to-background relative overflow-hidden">
        <ShaderAnimation />
        <div className="absolute inset-0 bg-grid opacity-20" />
        <div className="container mx-auto px-4 py-6 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/" className={buttonVariants({ variant: "ghost", size: "sm" })}>
                <Button>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Projects
                </Button>
              </Link>
              <Separator orientation="vertical" className="h-6" />

              {isEditing ? (
                <div className="flex flex-col gap-2 relative z-10">
                  <Input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder="Project Name"
                    className="glass-card"
                  />
                  <textarea
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    placeholder="Project Description"
                    className="glass-card border rounded-lg p-3 w-full"
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleUpdateProject} className="btn-glow">Save</Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsEditing(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="relative z-10">
                  <h1 className="text-4xl lg:text-5xl font-bold mb-3">
                    <span className="text-gradient">{project.name}</span>
                  </h1>
                  <p className="text-muted-foreground max-w-2xl text-lg leading-relaxed mb-4">
                    {project.description}
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setIsEditing(true)}
                    className="hover:shadow-glow-sm transition-all duration-300"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit
                  </Button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Stats - Glassmorphism Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 relative z-10">
            <Card className="glass-card border-border/30 hover:shadow-glow-sm transition-all duration-300">
              <CardContent className="p-5 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-glow-sm">
                  <BookOpen className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-gradient">{project.topicCount}</p>
                  <p className="text-xs text-muted-foreground font-medium">Topics</p>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-border/30 hover:shadow-glow-sm transition-all duration-300">
              <CardContent className="p-5 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center shadow-glow-sm">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-gradient">{project.paperCount}</p>
                  <p className="text-xs text-muted-foreground font-medium">Papers</p>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-border/30 hover:shadow-glow-sm transition-all duration-300">
              <CardContent className="p-5 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-glow-sm">
                  <Target className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-gradient">{project.progress}%</p>
                  <p className="text-xs text-muted-foreground font-medium">Complete</p>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-card border-border/30 hover:shadow-glow-sm transition-all duration-300">
              <CardContent className="p-5 flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-primary flex items-center justify-center shadow-glow-sm">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div>
                  <p className="text-sm font-bold">{project.lastModified}</p>
                  <p className="text-xs text-muted-foreground font-medium">Last activity</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm text-muted-foreground">
                {project.progress}%
              </span>
            </div>
            <Progress value={project.progress} className="h-2" />
          </div>
        </div>
      </div>

      {/* Topics */}
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-3">
              <span className="text-gradient">Research Topics</span>
            </h2>
            <p className="text-muted-foreground text-lg">
              Organize your literature review by topic areas
            </p>
          </div>

          {showAddTopic ? (
            <div className="flex flex-col gap-2">
              <Input
                value={topicName}
                onChange={(e) => setTopicName(e.target.value)}
                placeholder="Topic Name"
              />
              <textarea
                value={topicDescription}
                onChange={(e) => setTopicDescription(e.target.value)}
                placeholder="Topic Description"
                className="border rounded p-2 w-full"
              />
              <div className="flex gap-2">
                <Button onClick={handleAddTopic}>Add Topic</Button>
                <Button
                  variant="outline"
                  onClick={() => setShowAddTopic(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <Button onClick={() => setShowAddTopic(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Topic
            </Button>
          )}
        </div>

        <div className="mt-4 space-y-2">
          {topics.length === 0 ? (
            <div className="text-muted-foreground">
              No topics yet for this project.
            </div>
          ) : (
            topics.map((t) => (
              <Link
                key={t.topic_id}
                to={`/project/${projectId}/topic/${t.topic_id}`}
                className="block"
              >
                <Card className="card-glass border-border/30 hover:border-primary/50 hover:shadow-glow transition-all duration-300 cursor-pointer group relative overflow-hidden">
                  {/* Shader Animation Background */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-15 transition-opacity duration-500">
                    <ShaderAnimation />
                  </div>

                  <div className="h-0.5 w-full bg-gradient-to-r from-primary via-accent to-primary opacity-70 relative z-10" />
                  <CardContent className="p-5 relative z-10">
                    <h3 className="font-bold text-lg mb-2 group-hover:text-gradient transition-all duration-300">{t.topic_name}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {t.topic_description || "No description"}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))
          )}
        </div>

      </div>
    </div>
  );
};

export default ProjectDetail;
