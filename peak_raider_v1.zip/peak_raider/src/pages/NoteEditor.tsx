import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { supabase } from "@/lib/supabase";

interface Note {
  notes_id: number;
  project_id: number;
  topic_id: number;
  paper_id: number;
  paper_page: number | null;
  content: string;
  createdAt: string;
  updatedAt: string;
}

interface NoteEditorProps {
  note: { content: string } | null;
  onSave: (content: string) => void;
  currentPage: number;
}

export const NoteEditor = ({ note, onSave, currentPage }: NoteEditorProps) => {
  const [notesList, setNotesList] = useState<Note[]>([]);
  const [newNote, setNewNote] = useState("");
  const [saving, setSaving] = useState(false);

  // Fetch all notes for the current page
  useEffect(() => {
    const fetchNotes = async () => {
      const { data, error } = await supabase
        .from("RD_Notes")
        .select("*")
        .eq("paper_page", currentPage)
        .order("createdAt", { ascending: false });

      if (error) {
        console.error("Error fetching notes:", error);
        return;
      }
      setNotesList(data || []);
    };

    fetchNotes();
  }, [currentPage]);

  const handleSave = async () => {
    if (!newNote.trim()) return;

    setSaving(true);
    await onSave(newNote);

    // Refresh notes after saving
    const { data, error } = await supabase
      .from("RD_Notes")
      .select("*")
      .eq("paper_page", currentPage)
      .order("createdAt", { ascending: false });

    if (!error) setNotesList(data || []);

    setNewNote("");
    setSaving(false);
  };

  return (
    <motion.div
      key={currentPage}
      className="flex flex-col h-full bg-background border-l rounded-l-xl shadow-inner p-4"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.2 }}
    >
      {/* Header */}
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-sm font-semibold text-muted-foreground">
          Research Notes — Page {currentPage}
        </h2>
        <Button
          variant="outline"
          size="sm"
          onClick={async () => {
            const { data, error } = await supabase
              .from("RD_Notes")
              .select("*")
              .eq("paper_page", currentPage)
              .order("createdAt", { ascending: false });
            if (!error) setNotesList(data || []);
          }}
        >
          Refresh
        </Button>
      </div>

      {/* Scrollable notes list */}
      <div className="flex-1 overflow-y-auto mb-3 space-y-2 pr-2">
        {notesList.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            No notes yet for this page.
          </div>
        ) : (
          notesList.map((n) => (
            <div
              key={n.notes_id}
              className="bg-muted/40 p-3 rounded-lg shadow-sm border text-sm leading-relaxed"
            >
              {n.content}
              <div className="text-[10px] text-muted-foreground mt-1 text-right">
                {new Date(n.updatedAt).toLocaleString()}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add new note */}
      <div className="border-t pt-3">
        <Textarea
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          placeholder="Write a new note..."
          className="resize-none mb-2"
          rows={3}
        />
        <Button
          className="w-full"
          disabled={saving}
          onClick={handleSave}
        >
          {saving ? "Saving..." : "Add Note"}
        </Button>
      </div>
    </motion.div>
  );
};
