export interface Project {
  id: string;
  name: string;
  description: string;
  paperCount: number;
  topicCount: number;
  lastModified: string;
  progress: number;
  color: string;
  status: 'active' | 'completed' | 'archived';
  createdAt: string;
  topics: Topic[];
}

export interface Topic {
  id: string;
  name: string;
  description: string;
  projectId: string;
  paperCount: number;
  color: string;
  createdAt: string;
  papers: Paper[];
}

export interface Paper {
  id: string;
  title: string;
  authors: string[];
  abstract: string;
  topicId: string;
  projectId: string;
  pdfPath?: string;
  doi?: string;
  publicationDate?: string;
  journal?: string;
  tags: string[];
  readingProgress: number;
  createdAt: string;
  notes: Note[];
}

export interface Note {
  id: string;
  paperId: string;
  content: string;
  pdfPage?: number;
  pdfPosition?: { x: number; y: number };
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface FileSystemData {
  projects: Project[];
  settings: AppSettings;
}

export interface AppSettings {
  theme: 'light' | 'dark';
  fontSize: 'small' | 'medium' | 'large';
  autoSave: boolean;
  lastBackup?: string;
}