import { useState, useCallback } from 'react';
import { fileSystemService } from '@/services/fileSystemService';
import { Project } from '@/types';
import { useToast } from '@/hooks/use-toast';

export const useFileSystem = () => {
  const [hasAccess, setHasAccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const requestAccess = useCallback(async () => {
    setLoading(true);
    try {
      const granted = await fileSystemService.requestDirectoryAccess();
      setHasAccess(granted);
      
      if (granted) {
        toast({
          title: "Directory Access Granted",
          description: "You can now save and load projects locally.",
        });
      } else {
        toast({
          title: "Directory Access Denied",
          description: "Local file storage is not available.",
          variant: "destructive"
        });
      }
      
      return granted;
    } catch (error) {
      console.error('Error requesting directory access:', error);
      toast({
        title: "Error",
        description: "Failed to request directory access.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const saveProject = useCallback(async (project: Project) => {
    if (!hasAccess) {
      const granted = await requestAccess();
      if (!granted) return false;
    }

    try {
      await fileSystemService.saveProject(project);
      toast({
        title: "Project Saved",
        description: `${project.name} has been saved locally.`,
      });
      return true;
    } catch (error) {
      console.error('Error saving project:', error);
      toast({
        title: "Save Failed",
        description: "Failed to save project locally.",
        variant: "destructive"
      });
      return false;
    }
  }, [hasAccess, requestAccess, toast]);

  const loadProjects = useCallback(async (): Promise<Project[]> => {
    if (!hasAccess) return [];

    try {
      return await fileSystemService.loadProjects();
    } catch (error) {
      console.error('Error loading projects:', error);
      toast({
        title: "Load Failed",
        description: "Failed to load projects from local storage.",
        variant: "destructive"
      });
      return [];
    }
  }, [hasAccess, toast]);

  const savePDF = useCallback(async (projectId: string, topicId: string, paperId: string, file: File): Promise<string | null> => {
    if (!hasAccess) return null;

    try {
      return await fileSystemService.savePaperPDF(projectId, topicId, paperId, file);
    } catch (error) {
      console.error('Error saving PDF:', error);
      toast({
        title: "PDF Save Failed",
        description: "Failed to save PDF file.",
        variant: "destructive"
      });
      return null;
    }
  }, [hasAccess, toast]);

  const loadPDF = useCallback(async (pdfPath: string): Promise<Blob | null> => {
    if (!hasAccess) return null;

    try {
      return await fileSystemService.loadPaperPDF(pdfPath);
    } catch (error) {
      console.error('Error loading PDF:', error);
      return null;
    }
  }, [hasAccess]);

  return {
    hasAccess,
    loading,
    requestAccess,
    saveProject,
    loadProjects,
    savePDF,
    loadPDF
  };
};