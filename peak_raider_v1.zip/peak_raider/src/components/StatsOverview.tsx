import { Card } from "@/components/ui/card";
import { TrendingUp, BookOpen, FileText, Clock, Target } from "lucide-react";

interface StatsData {
  totalProjects: number;
  totalTopics: number;
  totalPapers: number;
  recentActivity: number;
  completionRate: number;
}

interface StatsOverviewProps {
  stats: StatsData;
}

export const StatsOverview = ({ stats }: StatsOverviewProps) => {
  const statItems = [
    {
      label: "Total Projects",
      value: stats.totalProjects,
      icon: BookOpen,
      color: "text-primary",
      bgColor: "bg-primary/10"
    },
    {
      label: "Topics",
      value: stats.totalTopics,
      icon: Target,
      color: "text-blue-400",
      bgColor: "bg-blue-500/10"
    },
    {
      label: "Papers",
      value: stats.totalPapers,
      icon: FileText,
      color: "text-purple-400",
      bgColor: "bg-purple-500/10"
    },
    {
      label: "Recent Activity",
      value: `${stats.recentActivity} days`,
      icon: Clock,
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10"
    },
    {
      label: "Completion Rate",
      value: `${stats.completionRate}%`,
      icon: TrendingUp,
      color: "text-yellow-400",
      bgColor: "bg-yellow-500/10"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
      {statItems.map((item, index) => (
        <Card key={item.label} className="card-premium animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
          <div className="p-6">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${item.bgColor}`}>
                <item.icon className={`h-5 w-5 ${item.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{item.value}</p>
                <p className="text-sm text-zinc-500">{item.label}</p>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};