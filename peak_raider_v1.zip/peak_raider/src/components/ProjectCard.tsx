import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import {
  MoreVertical,
  FileText,
  BookOpen,
  Clock
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ShaderAnimation } from "@/components/ui/shader-lines";

export interface Project {
  id: string;
  name: string;
  description: string;
  paperCount: number;
  topicCount: number;
  lastModified: string;
  progress: number;
  color: string;
  status: 'active' | 'completed' | 'archived';
}

interface ProjectCardProps {
  project: Project;
  onEdit?: (project: Project) => void;
  onDelete?: (project: Project) => void;
  onArchive?: (project: Project) => void;
  onClick?: (project: Project) => void;
}

export const ProjectCard = ({
  project,
  onEdit,
  onDelete,
  onArchive,
  onClick
}: ProjectCardProps) => {
  const navigate = useNavigate();
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="status-success">Completed</Badge>;
      case 'archived':
        return <Badge variant="secondary">Archived</Badge>;
      default:
        return <Badge className="status-academic">Active</Badge>;
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 50) return 'bg-blue-500';
    if (progress >= 25) return 'bg-yellow-500';
    return 'bg-zinc-600';
  };

  return (
    <Card className="card-premium group overflow-hidden relative">
      {/* Shader Animation Background */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500">
        <ShaderAnimation />
      </div>

      {/* Gradient accent bar */}
      <div
        className="h-1 w-full bg-gradient-to-r from-primary via-green-400 to-primary transition-all duration-500 relative z-10"
        style={{ opacity: 0.8 }}
      />

      <div className="p-6 relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1 cursor-pointer" onClick={() => navigate(`/project/${project.id}`)}>
            <div className="flex items-center gap-2 mb-2">
              <div
                className="w-3 h-3 rounded-full shadow-[0_0_10px_rgba(34,197,94,0.5)] transition-all duration-300 group-hover:scale-110"
                style={{ backgroundColor: project.color }}
              />
              <h3 className="font-bold text-xl text-white group-hover:text-primary transition-all duration-300">
                {project.name}
              </h3>
              {getStatusBadge(project.status)}
            </div>
            <p className="text-zinc-400 text-sm mb-3 line-clamp-2 leading-relaxed">
              {project.description}
            </p>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-all duration-300 text-zinc-400 hover:text-white hover:bg-zinc-800">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-zinc-900 border-zinc-800 text-zinc-300">
              <DropdownMenuItem onClick={() => onEdit?.(project)} className="focus:bg-zinc-800 focus:text-white">
                Edit Project
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onArchive?.(project)} className="focus:bg-zinc-800 focus:text-white">
                Archive Project
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => onDelete?.(project)}
                className="text-red-400 focus:bg-red-900/20 focus:text-red-300"
              >
                Delete Project
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-zinc-500 font-medium">Progress</span>
            <span className="font-bold text-lg text-white">{project.progress}%</span>
          </div>
          <div className="w-full bg-zinc-800 rounded-full h-2.5 overflow-hidden">
            <div
              className={`h-2.5 rounded-full transition-all duration-500 ${getProgressColor(project.progress)} shadow-[0_0_10px_rgba(34,197,94,0.3)]`}
              style={{ width: `${project.progress}%` }}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mt-5 pt-4 border-t border-zinc-800">
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <BookOpen className="h-4 w-4 text-primary" />
            <span className="font-medium text-zinc-300">{project.topicCount}</span>
            <span>topics</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-zinc-400">
            <FileText className="h-4 w-4 text-blue-400" />
            <span className="font-medium text-zinc-300">{project.paperCount}</span>
            <span>papers</span>
          </div>
        </div>

        <div className="flex items-center gap-2 mt-4 text-xs text-zinc-600">
          <Clock className="h-3.5 w-3.5" />
          <span>Updated {project.lastModified}</span>
        </div>
      </div>
    </Card>
  );
};