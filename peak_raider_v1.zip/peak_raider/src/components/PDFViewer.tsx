import React, { useState } from "react";
import { ChevronLeft, ChevronRight, Download, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface PDFViewerProps {
  pdfUrl: string | null;
  onPageChange?: (page: number) => void;
}

export const PDFViewer = ({ pdfUrl, onPageChange }: PDFViewerProps) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageInput, setPageInput] = useState("1");

  const goToPage = (page: number) => {
    if (page < 1) return;
    
    setCurrentPage(page);
    setPageInput(page.toString());
    
    if (onPageChange) {
      onPageChange(page);
    }
  };

  const handlePageInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPageInput(e.target.value);
  };

  const handlePageInputSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const page = parseInt(pageInput, 10);
    if (!isNaN(page) && page > 0) {
      goToPage(page);
    } else {
      setPageInput(currentPage.toString());
    }
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      goToPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    goToPage(currentPage + 1);
  };

  if (!pdfUrl) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <p className="text-muted-foreground">No PDF selected</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Toolbar */}
      <div className="flex items-center gap-2 p-2 border-b bg-muted/20">
        {/* Page Navigation for Notes */}
        <div className="flex items-center gap-2 bg-blue-50 border border-blue-200 rounded-md px-3 py-1">
          <span className="text-xs font-medium text-blue-700">Notes Page:</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={handlePrevPage}
            disabled={currentPage <= 1}
            className="h-7 w-7 p-0"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          
          <form onSubmit={handlePageInputSubmit} className="flex items-center gap-1">
            <Input
              type="text"
              value={pageInput}
              onChange={handlePageInputChange}
              className="w-16 h-7 text-center text-sm"
            />
          </form>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={handleNextPage}
            className="h-7 w-7 p-0"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        <div className="text-xs text-muted-foreground ml-2">
          Use arrows to view notes for different pages
        </div>

        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            asChild
          >
            <a
              href={pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              Open in New Tab
            </a>
          </Button>
        </div>
      </div>

      {/* PDF Iframe Container */}
      <div className="flex-1 relative">
        <iframe
          src={`${pdfUrl}#page=${currentPage}`}
          className="w-full h-full border-0"
          title="PDF Viewer"
        />
      </div>
    </div>
  );
};