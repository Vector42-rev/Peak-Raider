import { FileSystemData, Project, Paper } from '@/types';

class FileSystemService {
  private directoryHandle: FileSystemDirectoryHandle | null = null;

  async requestDirectoryAccess(): Promise<boolean> {
    if ('showDirectoryPicker' in window) {
      try {
        this.directoryHandle = await (window as any).showDirectoryPicker({
          mode: 'readwrite'
        });
        return true;
      } catch (error) {
        console.error('Directory access denied:', error);
        return false;
      }
    }
    return false;
  }

  async saveProject(project: Project): Promise<void> {
    if (!this.directoryHandle) return;

    try {
      const projectDir = await this.getOrCreateDirectory(this.directoryHandle, `project-${project.id}`);
      
      // Save project metadata
      const metadataFile = await projectDir.getFileHandle('metadata.json', { create: true });
      const writable = await metadataFile.createWritable();
      await writable.write(JSON.stringify(project, null, 2));
      await writable.close();

      // Save topics
      const topicsDir = await this.getOrCreateDirectory(projectDir, 'topics');
      for (const topic of project.topics) {
        const topicDir = await this.getOrCreateDirectory(topicsDir, `topic-${topic.id}`);
        const topicFile = await topicDir.getFileHandle('metadata.json', { create: true });
        const topicWritable = await topicFile.createWritable();
        await topicWritable.write(JSON.stringify(topic, null, 2));
        await topicWritable.close();

        // Save papers
        const papersDir = await this.getOrCreateDirectory(topicDir, 'papers');
        for (const paper of topic.papers) {
          const paperDir = await this.getOrCreateDirectory(papersDir, `paper-${paper.id}`);
          const paperFile = await paperDir.getFileHandle('metadata.json', { create: true });
          const paperWritable = await paperFile.createWritable();
          await paperWritable.write(JSON.stringify(paper, null, 2));
          await paperWritable.close();
        }
      }
    } catch (error) {
      console.error('Error saving project:', error);
      throw error;
    }
  }

  async loadProjects(): Promise<Project[]> {
    if (!this.directoryHandle) return [];

    try {
      const projects: Project[] = [];
      for await (const [name, handle] of (this.directoryHandle as any).entries()) {
        if (handle.kind === 'directory' && name.startsWith('project-')) {
          const project = await this.loadProject(handle);
          if (project) projects.push(project);
        }
      }
      return projects;
    } catch (error) {
      console.error('Error loading projects:', error);
      return [];
    }
  }

  async savePaperPDF(projectId: string, topicId: string, paperId: string, file: File): Promise<string> {
    if (!this.directoryHandle) throw new Error('No directory access');

    try {
      const projectDir = await this.getOrCreateDirectory(this.directoryHandle, `project-${projectId}`);
      const topicsDir = await this.getOrCreateDirectory(projectDir, 'topics');
      const topicDir = await this.getOrCreateDirectory(topicsDir, `topic-${topicId}`);
      const papersDir = await this.getOrCreateDirectory(topicDir, 'papers');
      const paperDir = await this.getOrCreateDirectory(papersDir, `paper-${paperId}`);
      
      const pdfFile = await paperDir.getFileHandle('document.pdf', { create: true });
      const writable = await pdfFile.createWritable();
      await writable.write(file);
      await writable.close();

      return `project-${projectId}/topics/topic-${topicId}/papers/paper-${paperId}/document.pdf`;
    } catch (error) {
      console.error('Error saving PDF:', error);
      throw error;
    }
  }

  async loadPaperPDF(pdfPath: string): Promise<Blob | null> {
    if (!this.directoryHandle) return null;

    try {
      const pathParts = pdfPath.split('/');
      let currentDir = this.directoryHandle;
      
      for (let i = 0; i < pathParts.length - 1; i++) {
        currentDir = await currentDir.getDirectoryHandle(pathParts[i]);
      }
      
      const file = await currentDir.getFileHandle(pathParts[pathParts.length - 1]);
      return await file.getFile();
    } catch (error) {
      console.error('Error loading PDF:', error);
      return null;
    }
  }

  private async loadProject(handle: FileSystemDirectoryHandle): Promise<Project | null> {
    try {
      const metadataFile = await handle.getFileHandle('metadata.json');
      const file = await metadataFile.getFile();
      const text = await file.text();
      return JSON.parse(text);
    } catch (error) {
      console.error('Error loading project metadata:', error);
      return null;
    }
  }

  private async getOrCreateDirectory(parent: FileSystemDirectoryHandle, name: string): Promise<FileSystemDirectoryHandle> {
    try {
      return await parent.getDirectoryHandle(name);
    } catch {
      return await parent.getDirectoryHandle(name, { create: true });
    }
  }
}

export const fileSystemService = new FileSystemService();