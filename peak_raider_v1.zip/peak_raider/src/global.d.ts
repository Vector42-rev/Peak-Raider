// src/global.d.ts
declare module "@nutrient-sdk/viewer" {
  const NutrientViewer: any;
  export default NutrientViewer;
}

declare global {
  interface Window {
    NutrientViewer?: any;
  }
}
